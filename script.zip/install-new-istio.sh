#!/bin/bash

echo "-------------------------------------------------------"
echo "- Go to the istio-installation directory ~!!"
echo "- Run 01 ~ 04 script"
echo "-------------------------------------------------------"
