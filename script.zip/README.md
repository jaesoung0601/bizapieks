# aws-pm-workspace

# TODO
1. Velero 설치 검토
2. MPoC, Cyber 계정의 Dev/Stg/Prd 에 Internal-facing NLB 매뉴얼 생성 검토 (Subnet, Routing, SG 등. 작업은 PM 시 수행)
3. BizAPI의 경우 ALB(managed by ingress) 검토
